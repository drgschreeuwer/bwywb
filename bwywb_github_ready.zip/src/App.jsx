import React from 'react'
import BWYWBTabletApp from './BWYWBTabletApp.jsx'

export default function App() {
  return <BWYWBTabletApp />
}
